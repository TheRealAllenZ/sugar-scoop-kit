# Public pages only

These files go on the live site. Ethical AI glass only.

- earn.html — main page
- earn-in.html — after they join
- hero-scoops.jpg
- mascot-helper.jpg
- ethical-ai-logo.png — official seal

No builder names. No pipeline notes. No operator scripts.
