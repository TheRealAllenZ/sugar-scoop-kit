# SUGAR SCOOP
## Ethical AI

We got the scoop. You bring the skills.

Scoop = the job. Sugar = the means.

Your long work story + one prompt. Any chat. Any CLI. Any bot.

This kit is $0. Keep the files. You still send every application.
