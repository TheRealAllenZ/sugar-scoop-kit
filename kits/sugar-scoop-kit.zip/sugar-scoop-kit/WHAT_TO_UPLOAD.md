# What to upload

1. Your long resume, CV, or bio. Longer is better. This is the only life the model may use.
2. Optional: companies, industries, or places you will not work.
3. Optional: a few job links you already care about.

Do not upload other people's private files. Do not upload passwords.
