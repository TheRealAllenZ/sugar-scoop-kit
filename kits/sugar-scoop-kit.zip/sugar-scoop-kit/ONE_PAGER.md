# One page

We got the scoop. You bring the skills.

Scoop = the job. Sugar = the means.

Bring your story. Answer plain questions. Get a short list. You send it.

Five looks. Two short pages. Hidden pay is not an apply.

Kit $0. Track $0.
ethicalai.me/sugar
