# How to run it

Same files. Same prompt. Different boxes.

1. New chat / project / gem / workspace / CLI session
2. Upload your long work story
3. Paste PROMPT.txt
4. Answer one question at a time
5. When a scoop fits, use the short page. You click apply.

| Tool | Files | Prompt |
|---|---|---|
| ChatGPT | Project files, or attach | Project instructions, or first message |
| Claude | Project knowledge | Project instructions, or first message |
| Gemini | Gem knowledge | Gem instructions |
| Grok | Attach on the message | Custom instructions, or first message |
| Cursor or any CLI | A folder | Rule file or first message |
| A bot you already use | Upload or paste | First message |
| Local model | Folder or pasted context | System prompt |

Do not send the long story as the application.
